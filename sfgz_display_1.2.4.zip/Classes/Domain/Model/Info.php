<?php
namespace Sfgz\SfgzDisplay\Domain\Model;


/***
 *
 * This file is part of the "Display" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Daniel Rueegg <daten@verarbeitung.ch>
 *
 ***/
/**
 * Zusätzliche Tages-Informatinen auf Display
 */
class Info extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{

    /**
     * datumAnzeige
     *  should be unique together with pid
     * 
     * @var \DateTime
     */
    protected $datumAnzeige = null;

    /**
     * infotext
     * 
     * @var string
     */
    protected $infotext = '';

    /**
     * ausblenden
     * 
     * @var int
     */
    protected $ausblenden = 0;

    /**
     * starttime
     * 
     * @var int
     */
    protected $starttime = null;

    /**
     * endtime
     * 
     * @var int
     */
    protected $endtime = null;

    /**
     * iBelegungen
     * 
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzDisplay\Domain\Model\Belegung>
     * @TYPO3\CMS\Extbase\Annotation\ORM\Cascade("remove")
     */
    protected $iBelegungen = null;

    /**
     * __construct
     */
    public function __construct()
    {

        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     * 
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->iBelegungen = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Returns the datumAnzeige
     * 
     * @return \DateTime $datumAnzeige
     */
    public function getDatumAnzeige()
    {
        return $this->datumAnzeige;
    }

    /**
     * Sets the datumAnzeige
     * 
     * @param \DateTime $datumAnzeige
     * @return void
     */
    public function setDatumAnzeige(\DateTime $datumAnzeige)
    {
        $this->datumAnzeige = $datumAnzeige;
    }

    /**
     * Returns the infotext
     * 
     * @return string $infotext
     */
    public function getInfotext()
    {
        return $this->infotext;
    }

    /**
     * Sets the infotext
     * 
     * @param string $infotext
     * @return void
     */
    public function setInfotext($infotext)
    {
        $this->infotext = $infotext;
    }

    /**
     * Returns the ausblenden
     * 
     * @return string $ausblenden
     */
    public function getAusblenden()
    {
        return $this->ausblenden;
    }

    /**
     * Sets the ausblenden
     * 
     * @param string $ausblenden
     * @return void
     */
    public function setAusblenden($ausblenden)
    {
        $this->ausblenden = $ausblenden;
    }

    /**
     * Returns the starttime
     * 
     * @return string $starttime
     */
    public function getStarttime()
    {
        return $this->starttime;
    }

    /**
     * Sets the starttime
     * 
     * @param string $starttime
     * @return void
     */
    public function setStarttime($starttime)
    {
        $this->starttime = $starttime;
    }

    /**
     * Returns the endtime
     * 
     * @return string $endtime
     */
    public function getEndtime()
    {
        return $this->endtime;
    }

    /**
     * Sets the endtime
     * 
     * @param string $endtime
     * @return void
     */
    public function setEndtime($endtime)
    {
        $this->endtime = $endtime;
    }

    /**
     * Adds a Belegung
     * 
     * @param \Sfgz\SfgzDisplay\Domain\Model\Belegung $iBelegungen
     * @return void
     */
    public function addIBelegungen(\Sfgz\SfgzDisplay\Domain\Model\Belegung $iBelegungen)
    {
        $this->iBelegungen->attach($iBelegungen);
    }

    /**
     * Removes a Belegung
     * 
     * @param \Sfgz\SfgzDisplay\Domain\Model\Belegung $iBelegungenToRemove The Belegung to be removed
     * @return void
     */
    public function removeIBelegungen(\Sfgz\SfgzDisplay\Domain\Model\Belegung $iBelegungenToRemove)
    {
        $this->iBelegungen->detach($iBelegungenToRemove);
    }

    /**
     * Returns the iBelegungen
     * 
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzDisplay\Domain\Model\Belegung> $iBelegungen
     */
    public function getIBelegungen()
    {
        return $this->iBelegungen;
    }

    /**
     * Sets the iBelegungen
     * 
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Sfgz\SfgzDisplay\Domain\Model\Belegung> $iBelegungen
     * @return void
     */
    public function setIBelegungen(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $iBelegungen)
    {
        $this->iBelegungen = $iBelegungen;
    }
}
