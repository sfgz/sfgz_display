#
# Table structure for table 'tx_sfgzdisplay_domain_model_info'
#
CREATE TABLE tx_sfgzdisplay_domain_model_info (

	datum_anzeige date DEFAULT NULL,
	infotext text,
	ausblenden int(4) unsigned DEFAULT '0' NOT NULL,
	i_belegungen int(11) unsigned DEFAULT '0' NOT NULL,

);

#
# Table structure for table 'tx_sfgzdisplay_domain_model_belegung'
#
CREATE TABLE tx_sfgzdisplay_domain_model_belegung (

	info int(11) unsigned DEFAULT '0' NOT NULL,

	belegungstext varchar(255) DEFAULT '' NOT NULL,
	zeit_von varchar(255) DEFAULT '' NOT NULL,
	zeit_bis varchar(255) DEFAULT '' NOT NULL,
	raum varchar(255) DEFAULT '' NOT NULL,
	person varchar(255) DEFAULT '' NOT NULL,

);

#
# Table structure for table 'tx_sfgzdisplay_domain_model_belegung'
#
CREATE TABLE tx_sfgzdisplay_domain_model_belegung (

	info int(11) unsigned DEFAULT '0' NOT NULL,

);
