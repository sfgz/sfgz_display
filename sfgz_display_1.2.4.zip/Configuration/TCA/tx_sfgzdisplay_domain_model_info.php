<?php
return [
    'ctrl' => [
        'title' => 'LLL:EXT:sfgz_display/Resources/Private/Language/locallang_db.xlf:tx_sfgzdisplay_domain_model_info',
        'label' => 'datum_anzeige',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'enablecolumns' => [
            'starttime' => 'starttime',
            'endtime' => 'endtime',
        ],
        'searchFields' => 'infotext',
        'iconfile' => 'EXT:sfgz_display/Resources/Public/Icons/tx_sfgzdisplay_domain_model_info.gif'
    ],
    'interface' => [
        'showRecordFieldList' => 'datum_anzeige, infotext, i_belegungen',
    ],
    'types' => [
        '1' => ['showitem' => 'datum_anzeige, infotext, i_belegungen, --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xlf:tabs.access, starttime, endtime,ausblenden'],
    ],
    'columns' => [
        'starttime' => [
            'exclude' => true,
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.starttime',
            'config' => [
                'type' => 'input',
                'renderType' => 'inputDateTime',
                'eval' => 'datetime,int',
                'default' => 0,
                'behaviour' => [
                    'allowLanguageSynchronization' => true
                ]
            ],
        ],
        'endtime' => [
            'exclude' => true,
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.endtime',
            'config' => [
                'type' => 'input',
                'renderType' => 'inputDateTime',
                'eval' => 'datetime,int',
                'default' => 0,
                'range' => [
                    'upper' => mktime(0, 0, 0, 1, 1, 2038)
                ],
                'behaviour' => [
                    'allowLanguageSynchronization' => true
                ]
            ],
        ],

        'datum_anzeige' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_display/Resources/Private/Language/locallang_db.xlf:tx_sfgzdisplay_domain_model_info.datum_anzeige',
            'config' => [
                'dbType' => 'date',
                'type' => 'input',
                'renderType' => 'inputDateTime',
                'size' => 12,
                'eval' => 'date',
                'default' => null,
            ],
        ],
        'infotext' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_display/Resources/Private/Language/locallang_db.xlf:tx_sfgzdisplay_domain_model_info.infotext',
            'config' => [
                'type' => 'text',
                'cols' => 40,
                'rows' => 15,
                'eval' => 'trim'
            ]
        ],
        'ausblenden' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_display/Resources/Private/Language/locallang_db.xlf:tx_sfgzdisplay_domain_model_info.ausblenden',
            'config' => [
                'type' => 'check',
                'value' => '1'
            ]
        ],
        'i_belegungen' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_display/Resources/Private/Language/locallang_db.xlf:tx_sfgzdisplay_domain_model_info.i_belegungen',
            'config' => [
                'type' => 'inline',
                'foreign_table' => 'tx_sfgzdisplay_domain_model_belegung',
                'foreign_field' => 'info',
                'maxitems' => 9999,
                'appearance' => [
                    'collapseAll' => 0,
                    'levelLinksPosition' => 'top',
                    'showSynchronizationLink' => 1,
                    'showPossibleLocalizationRecords' => 1,
                    'showAllLocalizationLink' => 1
                ],
            ],

        ],
    
    ],
];
