function reloadClockPage( miliseconds ) {
    var d = new Date();
    seconds = d.getSeconds();
    miliNow = (seconds*1000);
    reloadIn = (miliseconds-miliNow);
    setInterval(function() { location.reload(); }, reloadIn  );
}
function initOnlineClock( hours , minutes , seconds , autostart ) {
    if( hours.length > 0 && minutes.length > 0 && seconds.length > 0 && autostart == 1) {
        return php_initOnlineClock( hours , minutes , seconds , autostart ) ;
    }
    
    var d = new Date();
    if( hours.length < 1) hours = d.getHours();
    if( minutes.length < 1) minutes = d.getMinutes();
    if( seconds.length < 1) seconds = d.getSeconds();
    
    if( autostart ){
        initClock( hours , minutes , seconds );
    }else{
        setHands( hours , minutes , seconds );
    }
}

function initClock( hours , minutes , seconds ) {
        setHands( hours , minutes , seconds );
        setTimeout(function() {
            initOnlineClock( '' , '' , '' , 1 );
        } , 30 );
}

function setHands( hours , minutes , seconds ) {
	var contHour = document.querySelectorAll('.hours-container');
	var contMin = document.querySelectorAll('.minutes-container');
	var contSec = document.querySelectorAll('.seconds-container');
	if( !contHour[0] || !contMin[0] || !contSec[0] ) return;
    
    if( hours > 12 ) { hours -= 12 ; } // only 12 hours used, substract 12 if larger
    hoursDegree = ( hours * 30 ) ; // 12 h = 360 deg, 1 hour steps 30 degree 
    hoursDegree = hoursDegree + ( minutes / 2 );  // add minutes degree: 1 Minute moves the hour hand ( 60 min = 30 deg )
    hoursDegree = Math.round( hoursDegree / 6 ) * 6 ; // round to make 6 degree steps
    minutesDegree = minutes * 6; // 60 min = 360 deg, 1 minute steps 6 degree 
    secondsDegree = seconds * 6; // 60 sec = 360 deg, 1 second steps 6 degree 

    contHour[0].style.webkitTransform = 'rotateZ('+ hoursDegree +'deg)';
    contHour[0].style.transform = 'rotateZ('+ hoursDegree +'deg)';
    
    contMin[0].style.webkitTransform = 'rotateZ('+ minutesDegree +'deg)';
    contMin[0].style.transform = 'rotateZ('+ minutesDegree +'deg)';

    contSec[0].style.webkitTransform = 'rotateZ('+ secondsDegree +'deg)';
    contSec[0].style.transform = 'rotateZ('+ secondsDegree +'deg)';
}

/*
 * Set up the clock
 */
function php_initOnlineClock( hours , minutes , seconds , autostart) {
	var containers = document.querySelectorAll('.minutes-container');
	if( !containers[0] ) return;
    
    var d = new Date();
    if( hours.length < 1) hours = d.getHours();
    if( minutes.length < 1) minutes = d.getMinutes();
    if( seconds.length < 1) seconds = d.getSeconds();
//     if( autostart ){ seconds = 0; }
    
    php_initClock( hours , minutes , seconds );
     
	if( autostart ) php_moveSecondHands();
	php_setUpMinuteHands( autostart );
}
function php_initClock( hours , minutes , seconds ) {
  // Create an object with each hand and it's angle in degrees
  var hands = [
    {
      hand: 'hours',
      angle: (hours * 30) + (minutes / 2)
    },
    {
      hand: 'minutes',
      angle: (minutes * 6)
    },
    {
      hand: 'seconds',
      angle: (seconds * 6)
    }
  ];
  // Loop through each of these hands to set their angle
  for (var j = 0; j < hands.length; j++) {
    var elements = document.querySelectorAll('.' + hands[j].hand);
    for (var k = 0; k < elements.length; k++) {
        elements[k].style.webkitTransform = 'rotateZ('+ hands[j].angle +'deg)';
        elements[k].style.transform = 'rotateZ('+ hands[j].angle +'deg)';
        // If this is a minute hand, note the seconds position (to calculate minute position later)
        if (hands[j].hand === 'minutes') {
          elements[k].parentNode.setAttribute('data-second-angle', hands[j + 1].angle);
        }
    }
  }
}


/*
 * Set a timeout for the first minute hand movement (less than 1 minute), then rotate it every minute after that
 */
function php_setUpMinuteHands( autostart ) {
  // Find out how far into the minute we are
  var containers = document.querySelectorAll('.minutes-container');
  if( !containers[0] ) return;
  
  var secondAngle = containers[0].getAttribute("data-second-angle");
  if (secondAngle > 0) {
    if( autostart ){
        // Set a timeout until the end of the current minute, to move the hand
        var delay = (((360 - secondAngle) / 6) + 0.1) * 1000;
        setTimeout(function() {
            php_moveMinuteHands(containers); 
        } , delay );
    }else{ // run once
        php_moveMinuteHands(containers);
    }
  }
}

/*
 * Move the Minute container
 */
function php_moveMinuteHands(containers) {
  // Do the first minute's rotation
  for (var i = 0; i < containers.length; i++) {
    containers[i].style.webkitTransform = 'rotateZ(6deg)';
    containers[i].style.transform = 'rotateZ(6deg)';
  }
  // Then continue with a 60 second interval
  setInterval(function() {
    for (var i = 0; i < containers.length; i++) {
      if (containers[i].angle === undefined) {
        containers[i].angle = 12;
      } else {
        containers[i].angle += 6;
      }
      containers[i].style.webkitTransform = 'rotateZ('+ containers[i].angle +'deg)';
      containers[i].style.transform = 'rotateZ('+ containers[i].angle +'deg)';
    }
  }, 60000);
}

/*
 * Move the second containers
 */
function php_moveSecondHands() {
  var containers = document.querySelectorAll('.seconds-container');
  if( !containers[0] ) return;
  
  setInterval(function() {

      if (containers[0].angle === undefined) {
        containers[0].angle = 6;
      } else {
        containers[0].angle += 6;
      }

      containers[0].style.webkitTransform = 'rotateZ('+ containers[0].angle +'deg)';
      containers[0].style.transform = 'rotateZ('+ containers[0].angle +'deg)';

  }, 1000);
}
