<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Sfgz.SfgzDisplay',
            'Main',
            [
                'Info' => 'editor,vorschau,display,update',
            ],
            // non-cacheable actions
            [
                'Info' => 'editor,vorschau,display,update'
            ]
        );

        // wizards
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
            'mod {
                wizards.newContentElement.wizardItems.plugins {
                    elements {
                        main {
                            iconIdentifier = sfgz_display-plugin-main
                            title = LLL:EXT:sfgz_display/Resources/Private/Language/locallang_db.xlf:tx_sfgz_display_main.name
                            description = LLL:EXT:sfgz_display/Resources/Private/Language/locallang_db.xlf:tx_sfgz_display_main.description
                            tt_content_defValues {
                                CType = list
                                list_type = sfgzdisplay_main
                            }
                        }
                    }
                    show = *
                }
        }'
        );
        
		$iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class);
        $iconRegistry->registerIcon(
            'sfgz_display-plugin-main',
            \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
            ['source' => 'EXT:sfgz_display/Resources/Public/Icons/user_plugin_main.svg']
        );
		
        // Register scheduler-Tasks
        if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('scheduler')) {
            $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Sfgz\\SfgzDisplay\\Task\\CalendarImportTask'] = array(
                'extension'			=> 'SfgzDisplay',
                'title'				=> 'LLL:EXT:sfgz_display/Resources/Private/Language/locallang.xlf:scheduler.title_import_calendar',
                'description'		=> 'LLL:EXT:sfgz_display/Resources/Private/Language/locallang.xlf:scheduler.description_import_calendar',
                'additionalFields'	=> ''
            );
            $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Sfgz\\SfgzDisplay\\Task\\ClearbelegungTask'] = array(
                'extension'			=> 'SfgzDisplay',
                'title'				=> 'LLL:EXT:sfgz_display/Resources/Private/Language/locallang.xlf:scheduler.title_clear',
                'description'		=> 'LLL:EXT:sfgz_display/Resources/Private/Language/locallang.xlf:scheduler.description_clear',
                'additionalFields'	=> ''
            );
        }

    }
);
