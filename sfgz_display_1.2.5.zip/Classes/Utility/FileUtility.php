<?php
namespace Sfgz\SfgzDisplay\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Utility\ExtensionManagementUtility;

/** 
* Class FileUtility
* 
* 
*/

class FileUtility implements \TYPO3\CMS\Core\SingletonInterface {
    
    /**
    * fileAttributes
    *
    * @var array
    */
    public $fileAttributes = NULL;

    /**
        * pluginName
        *
        * @var string
        */
    Public $pluginName = null;

    /**
        * smlExtKey
        *
        * @var string
        */
    Public $smlExtKey = null;

    /**
        * dateiname
        *
        * @var string
        */
    Public $dateiname = 'dateiname';

    /**
        * uploadFolder
        *
        * @var string
        */
    Public $uploadFolder = '';

    /**
        * allowedSuffixes
        *
        * @var array
        */
    Public $allowedSuffixes = [ 'csv'=>'csv' , 'xls'=>'xls' , 'xlsx'=>'xlsx' , 'ods'=>'ods' ];

    /**
     * messages
     *
     * @var array
     */
    Public $messages = null;

	/**
	 * setVariables
	 *
     * @param array $aVariables
	 * @return void
	 */
	public function setVariables( $aVariables )
	{
        if( isset($aVariables['pluginName']) ) $this->pluginName = $aVariables['pluginName'];
        if( isset($aVariables['smlExtKey']) ) $this->smlExtKey = $aVariables['smlExtKey'];
        if( isset($aVariables['dateiname']) ) $this->dateiname = $aVariables['dateiname'];
        if( isset($aVariables['uploadFolder']) ) $this->uploadFolder = $aVariables['uploadFolder'];
    }
    
    /**
    * fileUpload
    *
    * @param string $subdir subfolder without leading path
    * @return string new filename
    */
    public function fileUpload( $subdir ) 
    {
        /**
        * 
        * The enctype is affored in the Form-Tag:
        *   form enctype="multipart/form-data"
        *   
        * The Input-Element on the Form looks like:
        *   input type="file" name="tx_{shrinked-extKey}_{pluginname}[dateiname]"
        *
        * Example for Plugin sfgz_converter_csv:
        *   extKey = sfgz_converter
        *   shrinkedExtKey = sfgzconverter
        *   pluginName = csv
        *   
        * The Input-Element on the Form looks like:
        *   input type="file" name="tx_sfgzconverter_csv[dateiname]"
        */
        $pathToFile = $this->uploadFolder . $subdir;
        $extKeyPlgNam = 'tx_' . $this->smlExtKey . '_' . $this->pluginName;
        $pathFileName = '';
        if ($_FILES[$extKeyPlgNam]['tmp_name'][ $this->dateiname ]) {
            $suffix = pathinfo( $_FILES[$extKeyPlgNam]['name'][ $this->dateiname ] , PATHINFO_EXTENSION );
            if( !isset($this->allowedSuffixes[$suffix]) ) {
                $this->messages[] = 'Dateiendung »'  . $suffix . '« nicht erlaubt.';
                return false;
            }
//            $pathFileName = rtrim($pathToFile,'/') . '/' . pathinfo( $_FILES[$extKeyPlgNam]['name'][ $this->dateiname ] , PATHINFO_FILENAME ) . '_' . date('ymdHis') . '.' . pathinfo( $_FILES[$extKeyPlgNam]['name'][ $this->dateiname ] , PATHINFO_EXTENSION );
            $pathFileName = rtrim($pathToFile,'/') . '/' . $_FILES[$extKeyPlgNam]['name'][ $this->dateiname ] ;
            if( file_exists($pathFileName) ) @unlink($pathFileName);
            \TYPO3\CMS\Core\Utility\GeneralUtility::upload_copy_move( $_FILES[$extKeyPlgNam]['tmp_name'][ $this->dateiname ] , $pathFileName );
        }
        return $pathFileName;
    }
    
    /**
    * remove_file
    *
    * @param string $subfolderFilename
    * @return array
    */
    public function remove_file( $subfolderFilename ) 
    {
        $filePathName = $this->uploadFolder . $subfolderFilename;
        if( file_exists($filePathName) ) return unlink($filePathName);
        return false;
    }
    
    /**
    * show a list of files
    *
    * @param string $subdir
    * @return array
    */
    public function show_file_list($subdir) 
    {
        $dumpPath = $this->uploadFolder . $subdir;
        if( !is_dir($dumpPath) ) return false;
        $d = dir( $dumpPath );
        $filelist = array();
        while (false !== ($entry = $d->read())) {
                $filename = $dumpPath.'/'.$entry;
                if( !is_file($filename) ) continue; // excludes also current dir . and upper dir ..
                $filelist[$entry]['suffix'] = strtolower( pathinfo( $entry , PATHINFO_EXTENSION ) );
                $filelist[$entry]['filename'] = pathinfo( $entry , PATHINFO_FILENAME );
                $filelist[$entry]['size'] = round( filesize($filename) / 1024 , 1 ) . ' KiB';
                $filelist[$entry]['bit'] = number_format( filesize($filename) , 0 , "." , "'" );
                $filelist[$entry]['time'] = filemtime( $filename );
                $filelist[$entry]['dateTime'] = date( 'd.m.Y H:i:s' , filemtime( $filename ) );
        }
        $d->close();
        ksort($filelist);

        return $filelist;
    }

    /**
    * downloadAsCsv
    * 
    * @param string $strOut 
    * @param string $filename
    * @return void
    */
    public function downloadAsCsv($strOut, $filename = 'verarbeitet.csv') 
    {
        header('Content-Type: application/csv');
        header('Content-Length: ' . strlen($strOut) );
        header('Content-Disposition: attachment; filename="'.$filename.'";');
        echo $strOut;
        die;
    }
	
	/**
	 * downloadFile
	 * used to download docx Documents. 
	 * can handle many mimetypes
	 *
     * @param string $fullPath
     * @param string $outputName optional, can be extracted
     * @param boolean $deleteFile optional, default ist false. deletes file after download
	 * @return void
	 */
	Public function downloadFile( $fullPath , $outputName = '' , $deleteFile = false )
	{
		if( !file_exists($fullPath) || !is_file($fullPath) ) return false;
		
		$fsize = filesize($fullPath);
		$path_parts = pathinfo($fullPath);
		if( !$outputName ) $outputName = $path_parts['basename'];
		$ext = strtolower($path_parts['extension']);
		
		if ($fd = fopen ($fullPath, 'r')) {
			if ($ext == 'pdf' || $ext == 'csv' ) {
				// use 'attachment' to force a download
				header('Content-type: application/' . $ext); 
				header('Content-Disposition: attachment; filename="'.$outputName.'"');
			}else{
				// Other document formats (doc, docx, odt, ods etc)
				header('Content-type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
				header('Content-Disposition: filename="'.$outputName.'"');
			}
			header('Content-length: '.$fsize);
			//header('Cache-control: private'); //use this to open files directly
            header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
            header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past
			while(!feof($fd)) {
				$buffer = fread($fd, 2048);
				echo $buffer;
			}
		}
		fclose ($fd);
		
		if( $deleteFile ) @unlink( $fullPath );
		
		exit;
	}

    /**
    * analyse_file
    * 
    * from Ashley, http://php.net/manual/de/function.fgetcsv.php
    * 
    * Example Usage:
    * $Array = analyse_file('/www/files/file.csv', 10);
    *
    * example usable parts
    * $Array['charset']['value'] => ISO-8859-15
    * $Array['delimiter']['value'] => ,
    * $Array['linebreak']['value'] => \r\n
    * 
    * @param string $file 
    * @param integer $capture_limit_in_kb
    * @return array 
    */
    function analyse_file($file, $capture_limit_in_kb = 10) 
    {
        // capture starting memory usage
        $output['peak_mem']['start']    = memory_get_peak_usage(true);

        // log the limit how much of the file was sampled (in Kb)
        $output['read_kb']                 = $capture_limit_in_kb;
    
        // read in file
        $fh = fopen($file, 'r');
            $contents = fread($fh, ($capture_limit_in_kb * 1024)); // in KB
        fclose($fh);
    
        // specify allowed field delimiters
        $delimiters = array(
            'comma'     => ',',
            'semicolon' => ';',
            'tab'         => "\t",
            'pipe'         => '|',
            'colon'     => ':'
        );
    
        // specify allowed line endings
        $linebreaks = array(
            'rn'         => "\r\n",
            'n'         => "\n",
            'r'         => "\r",
            'nr'         => "\n\r"
        );

        // loop and count each line ending instance
        foreach ($linebreaks as $key => $value) {
            $line_result[$key] = substr_count($contents, $value);
        }

        // sort by largest array value
        asort($line_result);

        // log to output array
        $output['linebreak']['results']     = $line_result;
        $output['linebreak']['count']     = end($line_result);
        $output['linebreak']['key']         = key($line_result);
        $output['linebreak']['value']     = $linebreaks[$output['linebreak']['key']];
        $lines = explode($output['linebreak']['value'], $contents);

        // remove last line of array, as this maybe incomplete?
        array_pop($lines);
    
        // create a string from the legal lines
        $complete_lines = implode(' ', $lines);
    
        // log statistics to output array
        $output['lines']['count']     = count($lines);
        $output['lines']['length']     = strlen($complete_lines);
    
        // loop and count each delimiter instance
        foreach ($delimiters as $delimiter_key => $delimiter) {
            $delimiter_result[$delimiter_key] = substr_count($complete_lines, $delimiter);
        }
    
        // sort by largest array value
        asort($delimiter_result);
    
        // log statistics to output array with largest counts as the value
        $output['delimiter']['results']     = $delimiter_result;
        $output['delimiter']['count']         = end($delimiter_result);
        $output['delimiter']['key']         = key($delimiter_result);
        $output['delimiter']['value']         = $delimiters[$output['delimiter']['key']];

        $output['charset']['list'] = 'utf-8,utf-16,ucs2,iso-10646-ucs-2,iso-8859-15,iso-8859-1,windows-1251';
        $charsetlist = explode( ',' , $output['charset']['list'] );
        foreach ($charsetlist as $item) {
            if( strtolower(mb_detect_encoding( $complete_lines , $item , true)) == strtolower($item) ){ // first test ok
                $sample = iconv($item, $item, $complete_lines);
                if (md5($sample) == md5($complete_lines)) { // second test ok
                    $output['charset']['value'] =  $item;
                    break;
                }
            }
        }
    
        // capture ending memory usage
        $output['peak_mem']['end'] = memory_get_peak_usage(true);
        
        $this->fileAttributes = $output;
        
        return array( 'charset'=>$output['charset']['value'] , 'delimiter'=>$output['delimiter']['value'] , 'linebreak'=>$output['linebreak']['value'] , 'delimiter_key'=>$output['delimiter']['key'] , 'linebreak_key'=>$output['linebreak']['key'] );
    }


} 
