<?php
namespace Sfgz\SfgzDisplay\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/** 
 * Class DateUtility
 * 
 * 
 */
 
class DateUtility implements \TYPO3\CMS\Core\SingletonInterface {

    /**
     * timeZoneString
     *
     * @var string
     */
    protected $timeZoneString = 'Europe/Zurich';

    /**
     * defaultTimeZoneString
     *
     * @var string
     */
    protected $defaultTimeZoneString = NULL;

    /**
     * timeZone
     *
     * @var \DateTimeZone
     */
    Public $timeZone = NULL;

	/**
	 * construct
	 *
	 * @return void
	 */
	public function __construct()
	{
			$typo3Timezone = $GLOBALS['TYPO3_CONF_VARS']['SYS']['phpTimeZone'] ; // MEZ | UCT
			if( $typo3Timezone ){
				$this->defaultTimeZoneString = $typo3Timezone;
			
			}else{
				$sysTimezone = date_default_timezone_get();
				$this->defaultTimeZoneString = $sysTimezone ? $sysTimezone : $this->timeZoneString;
			}
			
			$this->timeZone = new \DateTimeZone( $this->timeZoneString );
	}

	/**
	 * getStichtag
	 * returns stichtag if stichtag is set AND checkbox ist_stichtag is checked
	 * otherwise return today
	 *
	 * @return string
	 */
	Public function getStichtag()
	{
		$englDate = $englDate = date( 'Y-m-d' );
		$userObj = $GLOBALS['TSFE']->fe_user;
		
		if( $userObj ){ // normally data was already submitted and stored by ajax
			$settings_useroptions = $userObj->getKey( "user" , "SfgzKurs" );
 			if( 
				$settings_useroptions['stichtag'] && 
				$settings_useroptions['ist_stichtag'] 
 			) $englDate = $this->sanitizeDateTimeStringToEnglish( $settings_useroptions['stichtag'] );
		}
		
		return $englDate;
    }
    /**
        * storeStichtag
        *
        * @param string $stichdatum optional, empty for todays date
        * @return void
        */
    public function storeStichtag( $stichdatum = '' )
    {
        $userObj = $GLOBALS['TSFE']->fe_user;
        if( !$userObj ) return false;
        
        // get the incomed date-value
        $reqStichdatum = '';
        if( $stichdatum ){
            $reqStichdatum = $this->sanitizeGermanDateTimeString( $stichdatum );
            // store empty value if the incomed date corresponds todays date
            if( $reqStichdatum == date( 'd.m.Y' ) ) $reqStichdatum = '';
        }
        
        // get stored array
        $usrSess = $userObj->getKey( "user" , "SfgzKurs" );
        // change stichtag value in array. 
        $usrSess['stichtag'] = $reqStichdatum;
        // if date is empty then set stichtag-checkbox in array to unchecked.
        $usrSess['ist_stichtag'] = $reqStichdatum ? 1 : 0;
        
        // store array again
        $userObj->setKey("user","SfgzKurs", $usrSess);
        $userObj->sesData_change = true;
        $userObj->storeSessionData();

        return true;
    }

	/**
	 * sanitizeYear
	 *
     * @param str $yy
	 * @return str yyyy
	 */
	Public function sanitizeYear( $yy )
	{
			if( strlen($yy) == 2 ) return ( $yy + 2000 );
			return $yy;
	}

	Public function getGermanStichtag()
	{
        $englDate = $this->getStichtag();
        $stichday = ( $englDate == date( 'Y-m-d' ) ) ?  '' : $englDate;
        $stichtag = $this->sanitizeDateTimeStringToGerman($stichday);
        return $stichtag;
	}
	/**
	 * sanitizeDateTimeStringToGerman
	 * sanitize gernam dateString [ dd.mm.yyyy HH:ii ] to english dateString [ yyyy-mm-dd HH:ii ]
	 * 
	 * returns defaultValue if dateString was incorrect
	 *
     * @param str $strEnglishDate
     * @param str $defaultValue
	 * @return str german datestring or empty
	 */
	Public function sanitizeDateTimeStringToGerman( $strEnglishDate , $defaultValue = '' )
	{
			if( empty($strEnglishDate) ) return $defaultValue;

			$trmCnt = str_replace( 'T' , ' ' , trim($strEnglishDate) );
			$aDateTime = explode( ' ' , $trmCnt );
			
			// incomed value is german date
			$isGerman = (bool)preg_match("/^(0[1-9]|[1-2][0-9]|3[0-1]).(0[1-9]|1[0-2]).[0-9]{4}$/",$aDateTime[0]);
			if( $isGerman ) return $strEnglishDate;
			
			$aDate = explode( '-' , $aDateTime[0] );
			if( count($aDate) != 3 ) return $defaultValue;
			
			if(count($aDateTime) == 2){
				$strTime = str_replace( '.' , ':' , $aDateTime[1] ); // replace dots with :
			}else{
				$strTime = '';
			}
			
			$germDate = $aDate[2] . '.' . $aDate[1] . '.' . $this->sanitizeYear($aDate[0]) . ' ' . $strTime;
			return trim($germDate);
    }

	/**
	 * sanitizeDateTimeStringToEnglish
	 * sanitize gernam dateString [ dd.mm.yyyy HH:ii ] to english dateString [ yyyy-mm-dd HH:ii ]
	 * 
	 * returns defaultValue if dateString was incorrect
	 *
     * @param str $strMixedDate
     * @param str $defaultValue optional
	 * @return str english datestring or empty
	 */
	Public function sanitizeDateTimeStringToEnglish( $strMixedDate , $defaultValue = false )
	{
			if( empty($strMixedDate) ) return $defaultValue;
			
			$strMixedGdate = str_replace( 'T' , ' ' , trim($strMixedDate) );
			$aDateTime = explode( ' ' , $strMixedGdate );
			
			// incomed value is english date
			$isEnglish = (bool)preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$aDateTime[0]);

			if( $isEnglish ) return $strMixedDate;

			$strGdate = str_replace( '-' , '.' , $aDateTime[0] );
			$aDate = explode( '.' , $strGdate );
			if( count($aDate) != 3 ) return $defaultValue;
			
			// time string given
			if(count($aDateTime) == 2){
				$strTime = str_replace( '.' , ':' , $aDateTime[1] ); // replace dots with :
				if( strlen($strTime) == 5 ) $strTime .= ':00'; // add seconds if correct HH:MM
			}else{
				$strTime = '';
			}
			$englDate = $this->sanitizeYear($aDate[2]) . '-' . $aDate[1] . '-' . $aDate[0] . ' ' . $strTime;
			
			return trim($englDate);
    }

	/**
	 * sanitizeGermanDateTimeString
	 * sanitize gernam dateString [ dd.mm.yy ] to [ dd.mm.yyyy ]
	 * 
     * @param str $strShortGermanDate
	 * @return str german datestring or empty
	 */
	Public function sanitizeGermanDateTimeString( $strShortGermanDate )
	{ 
			if( strlen( $strShortGermanDate ) == 10 ) return $strShortGermanDate;
			if( empty( $strShortGermanDate ) ) return $strShortGermanDate;
			
			$dt = explode( '.' , $strShortGermanDate );
			$uxDate = mktime( 12 , 0 , 0 , $dt[1] , $dt[0] , $dt[2] );
			$dateObject = new \DateTime( date( 'Y-m-d\Th:i:s' , $uxDate ) , $this->timeZone );
			$localDate = $this->sanitizeDateTime( $dateObject );
			return $localDate->format('d.m.Y');
			
	}

	/**
	 * sanitizeDateTimestring
	 *
     * @param string $englishDate date in format Y-m-d H:i:s
	 * @return string
	 */
	Public function sanitizeDateTimestring( $englishDate )
	{
			$dateObject = new \DateTime( $englishDate , $this->timeZone );
			$localDate = $this->sanitizeDateTime( $dateObject );
			return $localDate->format('Y-m-d H:i:s');
	}

	/**
	 * sanitizeMixedDateTimestringToObject
	 *
     * @param string $dateTimeString english date like Y-m-d H:i:s OR germanDate d.m.Y
	 * @return \DateTime
	 */
	Public function sanitizeMixedDateTimestringToObject( $dateTimeString )
	{
			$englishDatestring = $this->sanitizeDateTimeStringToEnglish( $dateTimeString );
			
			if( $this->checkIsAValidDate($englishDatestring)) {
                if( strlen($englishDatestring) == 10 ) $englishDatestring .='T12:00:00';
				$dateObject = new \DateTime( $englishDatestring , $this->timeZone );

			} else {
			
				$dateObject = new \DateTime( date( 'Y-m-dT12:00:00' ) , $this->timeZone );
			}
			
			
			return $dateObject;
			$objDate = $this->sanitizeDateTime( $dateObject );
			return $objDate;
    }
    
	/**
	 * checkIsAValidDate
	 *
     * @param string $dateTimeString
	 * @return bool
	 */
	function checkIsAValidDate($dateTimeString){
		return (bool)strtotime($dateTimeString);
	}
	
	/**
	 * sanitizeDateTimestamp
	 *
     * @param int $timestamp optional, default is now
	 * @return \DateTime
	 */
	Public function sanitizeDateTimestamp( $timestamp = 0 )
	{
			if( empty($timestamp) ){
				$dateString = date( 'Y-m-d H:i:s' ) ;
				$dateObject = new \DateTime( $dateString );
			}else{
				$dateString = date( 'Y-m-d H:i:s' , $timestamp );
				$dateObject = new \DateTime( $dateString , $this->timeZone );
			}
			$objDate = $this->sanitizeDateTime( $dateObject );
			return $objDate;
    }

	/**
	 * sanitizeDateTime
	 *
     * @param \DateTime $dateObject
	 * @return \DateTime
	 */
	Public function sanitizeDateTime( $dateObject )
	{
		if( $this->defaultTimeZoneString == $this->timeZoneString ) {
			$dateObject->setTimezone( $this->timeZone );
			return $dateObject;
		}

		$offset = $this->timeZone->getOffset( $dateObject );
		
		if( $offset > 0 ) {
		
				$dateObject->add( new \DateInterval( 'PT' . $offset . 'S' ) );
		
		}elseif( $offset < 0 ){
		
				$dateObject->sub( new \DateInterval( 'PT' . $offset . 'S' ) );
		
		}
		
        return $dateObject;
    }
	
}
