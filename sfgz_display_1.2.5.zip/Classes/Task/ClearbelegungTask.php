<?php
namespace Sfgz\SfgzDisplay\Task;
 
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Scheduler\Task\AbstractTask;

 /** 
 * Class ClearbelegungTask
 * deletes old belegungen
 * 
 * 
 */
 
class ClearbelegungTask extends AbstractTask {

    /**
     * infoRepository
     * 
     * @var \Sfgz\SfgzDisplay\Domain\Repository\InfoRepository
     * @inject
     */
    protected $infoRepository = null;

    /**
        * belegungRepository
        *
        * @var \Sfgz\SfgzDisplay\Domain\Repository\BelegungRepository
        */
    protected $belegungRepository = null;

    /**
        * dateUtility
        *
        * @var \Sfgz\SfgzDisplay\Utility\DateUtility
        */
    protected $dateUtility = null;

    /**
     * extConf
     * 
     * @var array
     */
    Public $extConf = [];


	/**
	 * @var \TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager
	 * @inject
	 */
	protected $persistenceManager = NULL;

	/**
	* initiate
	*
	* @return void
	*/
	public function initiate( ) {
			$this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
			$flashMessageService = $this->objectManager->get(\TYPO3\CMS\Core\Messaging\FlashMessageService::class);
			$this->messageQueue = $flashMessageService->getMessageQueueByIdentifier();
			
            $this->dateUtility = GeneralUtility::makeInstance('Sfgz\\SfgzDisplay\\Utility\\DateUtility');

            $objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
            $this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');

            $querySettings = $objectManager->get('TYPO3\CMS\\Extbase\\Persistence\\Generic\\Typo3QuerySettings');
            $querySettings->setRespectStoragePage(FALSE);

            $this->infoRepository = $objectManager->get('Sfgz\\SfgzDisplay\\Domain\\Repository\\InfoRepository');
            $this->infoRepository->setDefaultQuerySettings($querySettings);
            
            $this->belegungRepository = $objectManager->get('Sfgz\\SfgzDisplay\\Domain\\Repository\\BelegungRepository');
            $this->belegungRepository->setDefaultQuerySettings($querySettings);
            
            $extensionConfig = GeneralUtility::makeInstance( \TYPO3\CMS\Core\Configuration\ExtensionConfiguration::class ); 
            $this->extConf = $extensionConfig->get('sfgz_display');
	}

	public function execute(){
			$this->initiate();
            
            $amountOfDeleted = $this->deleteInfoAndBelegungOlderThanDate();
			
			// create flashMessage
			$message = GeneralUtility::makeInstance(
					'TYPO3\\CMS\\Core\\Messaging\\FlashMessage',
					count($amountOfDeleted) . ' Einträge wurden gelöscht.',
					'Gelöscht', 
					count($amountOfDeleted) ? \TYPO3\CMS\Core\Messaging\FlashMessage::OK : \TYPO3\CMS\Core\Messaging\FlashMessage::INFO
			);
			$this->messageQueue->addMessage($message);
			
			return true;
	}
	
	
	Private function deleteInfoAndBelegungOlderThanDate()
	{
        $deleteDateObject = $this->dateUtility->sanitizeMixedDateTimestringToObject( date( 'Y.m.d' ) );
        $deleteDateObject->sub(new \DateInterval('P' . $this->extConf['belegung_age_in_days'] . 'D'));
        $engDateNow = $deleteDateObject->format('Y-m-d');

        $aObjInfo = $this->infoRepository->findAll();
		if( !$aObjInfo || !count($aObjInfo) ) {
            return [];
		}
        
        $aPermaInfo = [];
		foreach( $aObjInfo as $i => $objInfo ){
            $sEnddate = date( 'Y-m-d' , $objInfo->getEndtime() );
            $sDatumAnzeige = $objInfo->getDatumAnzeige()->format('Y-m-d');
            if( ( empty($sEnddate) || $sEnddate < $engDateNow ) && $sDatumAnzeige < $engDateNow ){
                // this element has to be deleted
                $aPermaInfo[$objInfo->getUid()] = $objInfo->getUid();
                // delete subrecords
                $objsBelegungen = $objInfo->getIBelegungen() ;
                if( count($objsBelegungen) ){
                    foreach( $objsBelegungen as $ix => $objBelToDel ){
                        $this->belegungRepository->remove($objBelToDel);
                    }
                }
                // delete master-record
                $this->infoRepository->remove($objInfo);
                // persist both
                $this->persistenceManager->persistAll();
            }
		}
		return $aPermaInfo;
		
    }

}
