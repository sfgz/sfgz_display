<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Sfgz.SfgzDisplay',
            'Main',
            'Info Display'
        );

        $pluginSignature = str_replace('_', '', 'sfgz_display') . '_main';
        $GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue($pluginSignature, 'FILE:EXT:sfgz_display/Configuration/FlexForms/flexform_main.xml');

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('sfgz_display', 'Configuration/TypoScript', 'Display');



        ### IMPORT definitions
        ### BelegungModel
            // Load description of table tx_mffdb_domain_model_klasse
            // Typo3 7.6 ? // t3lib_div::loadTCA('tx_mffdb_domain_model_klasse');
        
        // Add the sfgzdisplay information to the ctrl section
//         $GLOBALS['TCA']['tx_sfgzdisplay_domain_model_belegung']['ctrl']['sfgzdisplay'] = array(
//             0 => array(
//                 'connector' => 'csv',
//                 'parameters' => array(
//                     'path' => 'uploads/tx_sfgzdisplay/inc/',
//                     'hook' => 'belegung_processResponse',
//                     'encoding' => 'utf8'
//                 ),
//                 'data' => 'array',
//                 'referenceUid' => 'class_id',
//                 'enforcePid' => TRUE,
//                 'priority' => 110,
//                 'disabledOperations' => 'delete',
//                 'description' => 'Importiert Belegung ab CSV-Datei'
//             )
//         );

//         $GLOBALS['TCA']['tx_sfgzudb_domain_model_klasse']['columns']['pid']['external'] = array(
//             0 => array(
//                 'field' => 'pid'
//             )
//         );

    }
);
